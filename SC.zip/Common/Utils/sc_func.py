# -*- coding: UTF-8 -*-

import os
import re
import time
import shutil
import zipfile
import threading
from json import loads
from collections import OrderedDict


class Singleton(object):
    """ 使用__new__实现抽象单例 """

    def __new__(cls, *args, **kwargs):
        if not hasattr(cls, '_instance'):
            cls._instance = super(Singleton, cls).__new__(cls)
        return cls._instance


class JSONParser:
    """ JSON解析器 """

    @classmethod
    def parser(cls, json_path):
        with open(json_path, 'r', encoding='UTF-8') as f:
            return loads(f.read(), object_pairs_hook=OrderedDict)

class Common:
    """ 第三方公共方法 """

    @classmethod
    def is_exists(cls, dir):
        return os.path.exists(dir)

    @classmethod
    def is_file(cls, file_path):
        return os.path.isfile(file_path)

    @classmethod
    def rm_dir(cls, path):
        return shutil.rmtree(path)

    @classmethod
    def remove(cls, file_path):
        return os.remove(file_path)

    @classmethod
    def mkdir(cls, dir):
        try:
            os.makedirs(dir)
        except FileExistsError:
            pass

    @classmethod
    def get_pid(cls):
        return os.getpid()

    @classmethod
    def basename(cls, file_path):
        return os.path.split(file_path)[1]

    @classmethod
    def file_size(cls, file_path):
        if not cls.is_file(file_path):
            return 0
        return os.path.getsize(file_path)

    @classmethod
    def get_time(cls, format=True):
        if format:
            return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
        return time.strftime("%Y%m%d%H%M%S", time.localtime())

    @classmethod
    def write_to_file(cls, filename, info):
        try:
            with open(filename, 'w') as f:
                f.write(info)
                return True
        except:
            return False

    @classmethod
    def create_thread(cls, func, args=()):
        th = threading.Thread(target=func, args=args)
        th.setDaemon(True)
        th.start()

    @classmethod
    def is_ip(cls, ip):
        p = re.compile("^((25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(25[0-5]|2[0-4]\d|[01]?\d\d?)$")
        return p.match(ip)

    @classmethod
    def sleep(cls, sec):
        time.sleep(sec)

    @classmethod
    def zip_dir(cls, dirname, zipname):
        filelist = []
        if os.path.isfile(dirname):
            filelist.append(dirname)
        else:
            for root, dirs, files in os.walk(dirname):
                for name in files:
                    filelist.append(os.path.join(root, name))
        zf = zipfile.ZipFile(zipname, "w", zipfile.zlib.DEFLATED)
        for tar in filelist:
            arcname = tar[len(dirname):]
            zf.write(tar, arcname)
        zf.close()
    
    @classmethod
    def unzip_file(cls, file_path, path):
        if not zipfile.is_zipfile(file_path):
            return False
        with zipfile.ZipFile(file_path, 'r') as zip:
            zip.extractall(path)
        return True

    @classmethod
    def exist_suffix_file(cls, dirname, suffix):
        for file in os.listdir(dirname):
            f_split = os.path.splitext(file)
            if f_split[1] == suffix:
                return True, f_split[0]
        return False, None
