# -*- coding: UTF-8 -*-

from . import sc_gui


class App():

    def __init__(self):
        self.app = sc_gui.Gui()

    def run(self):
        self.app.pack()
        self.app.mainloop()


